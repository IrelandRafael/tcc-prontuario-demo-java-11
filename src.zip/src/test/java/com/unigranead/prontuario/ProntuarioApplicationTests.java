package com.unigranead.prontuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProntuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
