package com.unigranead.tcc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unigranead.tcc.entities.Funcionario;

public interface FuncionarioRepository extends JpaRepository<Funcionario, Integer>{

}
