package com.unigranead.tcc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unigranead.tcc.entities.Prontuario;

public interface ProntuarioRepository extends JpaRepository<Prontuario, Integer>{
	
}
