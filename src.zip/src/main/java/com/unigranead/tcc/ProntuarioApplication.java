package com.unigranead.tcc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProntuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProntuarioApplication.class, args);

	}

}
